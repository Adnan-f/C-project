#ifndef LIAT_H
#define LIAT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void file_treat(FILE* f, char* var, char* argv[]);
char* alloc();

#endif
