#ifndef CW_H
#define CW_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void wordCount(FILE* f,char*argv[]);
void wcarg(FILE* f,char*argv[]);

#endif
