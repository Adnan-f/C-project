#include "cw.h"

void wordCount(FILE* f,char*argv[]){
	char* txt=NULL;
	txt=malloc(1000000*sizeof(char));
		f=fopen(argv[1],"r");
		int d=0;
		for(int i=0; i<1000000; i++){
			fscanf(f,"%c",&txt[i]);
		}
			for (int i=0; i<1000000; i++){
		if (txt[i]=='\n'){
			d++;
			}
	}
	
	switch (d){
		case 1:
			printf("1  ");
			break;
		default:
			printf("%d  ", d);
		}
		d=0;
		int w=0;
		char* word=NULL;
		word=malloc(1000000*sizeof(char));
		rewind(f);
		while(!feof(f)){
			fscanf(f,"%s",word);
			w++;
			}
		printf("%d  ", w-1);
	for (int i=0; i<strlen(txt); i++){
			d++;
			}
	switch (d){
		case 1:
			printf("1  ");
			break;
		default:
			printf("%d  ", d);
		}
	printf("%s", argv[1]);
	
	printf("\n");
	fclose(f);
}

void wcarg(FILE* f,char*argv[]){
	int d=0;
	char* txt=NULL;
	txt=malloc(1000000*sizeof(char));
	f=fopen(argv[2],"r");
	for(int i=0; i<1000000; i++){
		fscanf(f,"%c",&txt[i]);
	}
	if(strcmp(argv[1], "-w")==0){
	int w=0;
		char* word=NULL;
		word=malloc(1000000*sizeof(char));
		rewind(f);
		while(!feof(f)){
			fscanf(f,"%s",word);
			w++;
			}
		printf("%d  ", w-1);
	}
	if(strcmp(argv[1], "-l")==0){
	for (int i=0; i<1000000; i++){
		if (txt[i]=='\n'){
			d++;
			}
	}
	switch (d){
		case 1:
			printf("1  ");
			break;
		default:
			printf("%d  ", d);
		}
		
	}
	if(strcmp(argv[1], "-m")==0){
	for (int i=0; i<strlen(txt); i++){
			d++;
			}
	
	switch (d){
		case 1:
			printf("1  ");
			break;
		default:
			printf("%d  ", d);
		}
	}
	printf("%s", argv[2]);
	printf("\n");
	fclose(f);
}
