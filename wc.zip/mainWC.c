#include "cw.h"

int main(int argc, char* argv[]){
	FILE* f=NULL;
	if (argc<=2) wordCount(f,argv, argc);
	else wcarg(f,argv, argc);
	return 0;
}
