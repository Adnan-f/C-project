#include "cw.h"

int main(int argc, char* argv[]){
	FILE* f=NULL;
	if (argc<=2) wordCount(f,argv);
	else wcarg(f,argv);
	return 0;
}
